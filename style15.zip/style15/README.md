# style15 2.0 — iOS 6 → iOS 15

## Сборка
    make package                         # .deb в ./packages
    make package install THEOS_DEVICE_IP=<ip>

## Что внутри
| Модуль | Файл | Что делает |
|---|---|---|
| Домашний экран | Source/Home.xm | сквиркл-иконки, плавающий док, Search-pill, бейджи, папки, пружинное нажатие, обои |
| Статус-бар | Source/StatusBar.xm | время слева, сигнал/Wi‑Fi/батарея справа, центр свободен (в SpringBoard и во всех приложениях) |
| Экран блокировки | Source/LockScreen.xm | крупные часы, дата, фонарик, камера, swipe-up для разблокировки |
| Пункт управления | Source/ControlCenter.xm | связь, музыка, яркость, громкость, быстрые приложения |
| Dynamic Island | Source/Island.xm | музыка, зарядка, беззвучный, уведомления; пружинный морфинг |
| Жесты | Source/Gestures.xm | низ ↑ = домой, удержание = переключатель, ← → = пред. приложение, верх-право ↓ = ЦУ |
| Ядро | Source/Core.xm | настройки, пружины, действия, события, загрузка модулей |

## Свои функции
1. Жесты: `/Library/Style15/Gestures.plist` — привяжи любое действие.
2. Модули: `Examples/HelloModule` — отдельный .bundle в `/Library/Style15/Modules`.
   API: `Public/Style15API.h` (`registerAction`, `observeEvent`, `S15Island present`, `S15SpringAnimate`).
3. Остров: любой код вызывает `[[S15Island shared] present:activity]`.

## Что обязательно проверить на устройстве (⚠)
Приватные API iOS 6 различаются между 6.0 и 6.1.x. Сверь class-dump'ом:
`SBIconImageView`, `SBDockView`, `SBAwayView`, `SBAwayController`, `SBMediaController`,
`BBServer publishBulletin:destinations:`, `SBUIController _toggleSwitcher`, `SBAppSwitcherModel`,
действие `lock` (селектор `lockDevice:`), уведомление `SBMediaNowPlayingChangedNotification`.
Хук с неверным именем просто не сработает, остальное продолжит работать.
