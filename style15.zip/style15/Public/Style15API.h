// Style15API.h — публичный API для модулей (.bundle в /Library/Style15/Modules)
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

typedef void (^S15ActionHandler)(NSDictionary *args);
typedef void (^S15EventHandler)(NSDictionary *info);

// ---------- Ядро: действия и события ----------
@interface S15Core : NSObject
+ (instancetype)shared;
// Действия можно вешать на жесты (Gestures.plist) и кнопки острова
- (void)registerAction:(NSString *)name handler:(S15ActionHandler)handler;
- (BOOL)performAction:(NSString *)name args:(NSDictionary *)args;
- (NSArray *)actionNames;
// Шина событий: "prefs.reload" и любые твои
- (void)observeEvent:(NSString *)name handler:(S15EventHandler)handler;
- (void)postEvent:(NSString *)name info:(NSDictionary *)info;
@end

// Модуль: принципальный класс бандла
@protocol S15Module <NSObject>
@optional
+ (NSString *)moduleName;
- (void)moduleDidLoad;          // вызывается внутри SpringBoard
@end

// ---------- Dynamic Island ----------
@interface S15IslandActivity : NSObject
@property (nonatomic, copy)   NSString *identifier;   // одинаковый id = обновление
@property (nonatomic, copy)   NSString *leading;      // компактный вид, слева
@property (nonatomic, copy)   NSString *trailing;     // компактный вид, справа
@property (nonatomic, copy)   NSString *title;        // развёрнутый вид
@property (nonatomic, copy)   NSString *subtitle;
@property (nonatomic, strong) UIColor  *accent;
@property (nonatomic, assign) CGFloat   progress;     // 0..1, <0 = без полоски
@property (nonatomic, assign) NSTimeInterval duration;         // >0: развернуть и убрать через N сек
@property (nonatomic, assign) NSTimeInterval expandedDuration; // >0: развернуть на N сек, потом свернуть
@property (nonatomic, copy)   NSString *tapAction;    // действие по тапу на развёрнутый остров
@property (nonatomic, copy)   NSArray  *buttons;      // [{title:, action:, args:}]
@end

@interface S15Island : NSObject
+ (instancetype)shared;
- (void)present:(S15IslandActivity *)activity;
- (void)dismissIdentifier:(NSString *)identifier;
@end

// ---------- Анимации ----------
// Пружина для CALayer. from/to: NSNumber или NSValue(CGPoint/CGSize/CGRect).
// zeta: 0.4 (пружинистее) ... 1.0 (без отскока)
void S15SpringAnimate(CALayer *layer, NSString *keyPath, id from, id to, CGFloat duration, CGFloat zeta);

// ---------- Настройки ----------
BOOL    S15Pref(NSString *key, BOOL def);
CGFloat S15PrefFloat(NSString *key, CGFloat def);
BOOL    S15IsSpringBoard(void);
