// Dynamic Island: чёрная «таблетка» над статус-баром, морфится пружиной между
// compact / expanded. События: музыка, зарядка, беззвучный режим, уведомления (BBServer).
#import "Private.h"

@implementation S15IslandActivity
- (id)init { if ((self = [super init])) { _progress = -1; } return self; }
@end

@interface S15PassWindow : UIWindow
@property (nonatomic, unsafe_unretained) UIView *hit;
@end
@implementation S15PassWindow
- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent *)e { return _hit && !_hit.hidden && CGRectContainsPoint(_hit.frame, p); }
@end

@implementation S15Island {
    S15PassWindow *_win;
    UIView *_pill;
    UILabel *_lead, *_trail, *_title, *_sub;
    UIView *_barBg, *_barFill;
    NSMutableArray *_buttons;
    NSMutableArray *_stack;
    S15IslandActivity *_cur;
    BOOL _expanded;
    NSTimer *_timer;
}
+ (instancetype)shared { static S15Island *i; static dispatch_once_t o; dispatch_once(&o, ^{ i = [S15Island new]; }); return i; }

- (id)init {
    if ((self = [super init])) {
        _stack = [NSMutableArray new]; _buttons = [NSMutableArray new];
        CGFloat W = [UIScreen mainScreen].bounds.size.width;
        _win = [[S15PassWindow alloc] initWithFrame:CGRectMake(0, 0, W, 130)];
        _win.windowLevel = 2500; _win.backgroundColor = [UIColor clearColor]; _win.hidden = YES;

        _pill = [[UIView alloc] initWithFrame:CGRectZero];
        _pill.backgroundColor = [UIColor blackColor];
        _pill.clipsToBounds = YES;
        [_win addSubview:_pill]; _win.hit = _pill;
        [_pill addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped)]];
        UISwipeGestureRecognizer *sw = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swiped)];
        sw.direction = UISwipeGestureRecognizerDirectionUp; [_pill addGestureRecognizer:sw];

        _lead  = [self label:16 font:@"HelveticaNeue-Bold" color:[UIColor whiteColor]];
        _trail = [self label:13 font:@"HelveticaNeue-Bold" color:[UIColor whiteColor]];
        _title = [self label:15 font:@"HelveticaNeue-Bold" color:[UIColor whiteColor]];
        _sub   = [self label:13 font:@"HelveticaNeue" color:[UIColor colorWithWhite:1 alpha:0.6f]];
        _trail.textAlignment = UITextAlignmentRight;
        _barBg = [UIView new]; _barBg.backgroundColor = [UIColor colorWithWhite:1 alpha:0.2f]; _barBg.layer.cornerRadius = 2;
        _barFill = [UIView new]; _barFill.layer.cornerRadius = 2;
        [_pill addSubview:_barBg]; [_barBg addSubview:_barFill];
    }
    return self;
}
- (UILabel *)label:(CGFloat)sz font:(NSString *)f color:(UIColor *)c {
    UILabel *l = [UILabel new]; l.backgroundColor = [UIColor clearColor];
    l.font = [UIFont fontWithName:f size:sz]; l.textColor = c; [_pill addSubview:l]; return l;
}

#pragma mark Размеры состояний
- (CGSize)sizeForExpanded:(BOOL)ex {
    CGFloat W = [UIScreen mainScreen].bounds.size.width;
    if (!ex) return CGSizeMake(_cur.trailing.length ? 132 : 92, 30);
    return CGSizeMake(MIN(W - 16, 340), _cur.buttons.count ? 108 : (_cur.progress >= 0 ? 78 : 66));
}
- (CGRect)frameForExpanded:(BOOL)ex {
    CGSize s = [self sizeForExpanded:ex];
    CGFloat W = _win.bounds.size.width;
    return CGRectMake((W - s.width) / 2, ex ? 8 : 5, s.width, s.height);
}
- (void)layoutContentExpanded:(BOOL)ex {
    CGSize s = [self sizeForExpanded:ex];
    if (!ex) {
        _lead.frame = CGRectMake(12, 0, 40, s.height); _lead.textAlignment = UITextAlignmentLeft;
        _trail.frame = CGRectMake(s.width - 62, 0, 50, s.height);
        _lead.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:14];
    } else {
        _lead.frame = CGRectMake(16, 14, 30, 30); _lead.textAlignment = UITextAlignmentCenter;
        _lead.font = [UIFont systemFontOfSize:24];
        _trail.frame = CGRectZero;
        _title.frame = CGRectMake(56, 12, s.width - 72, 20);
        _sub.frame = CGRectMake(56, 32, s.width - 72, 18);
        CGFloat by = 56;
        if (_cur.progress >= 0) {
            _barBg.frame = CGRectMake(16, 58, s.width - 32, 4);
            _barFill.frame = CGRectMake(0, 0, (s.width - 32) * MAX(0, MIN(1, _cur.progress)), 4);
            by = 68;
        }
        NSUInteger n = _buttons.count;
        CGFloat bw = n ? (s.width - 32 - (n - 1) * 8) / n : 0;
        for (NSUInteger i = 0; i < n; i++) ((UIView *)_buttons[i]).frame = CGRectMake(16 + i * (bw + 8), by, bw, 30);
    }
}

#pragma mark Показ
- (void)present:(S15IslandActivity *)a {
    if (![NSThread isMainThread]) { dispatch_async(dispatch_get_main_queue(), ^{ [self present:a]; }); return; }
    if (!S15Pref(@"enabled", YES) || !S15Pref(@"island", YES)) return;
    BOOL first = (_cur == nil);
    if (_cur && ![_cur.identifier isEqual:a.identifier] && _cur.duration == 0) [_stack addObject:_cur];
    _cur = a;
    [self rebuildButtons];
    _lead.text = a.leading; _trail.text = a.trailing; _title.text = a.title; _sub.text = a.subtitle;
    _barFill.backgroundColor = a.accent ?: S15Blue();
    _trail.textColor = a.accent ?: [UIColor whiteColor];
    _win.hidden = NO;
    BOOL ex = (a.duration > 0 || a.expandedDuration > 0);
    [self setExpanded:ex animated:YES fromHidden:first];
    [self armTimer];
    [[S15Core shared] postEvent:@"island.shown" info:@{@"id": a.identifier ?: @""}];
}
- (void)rebuildButtons {
    for (UIView *b in _buttons) [b removeFromSuperview];
    [_buttons removeAllObjects];
    NSUInteger i = 0;
    for (NSDictionary *d in _cur.buttons) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i++;
        b.backgroundColor = [UIColor colorWithWhite:1 alpha:0.16f];
        b.layer.cornerRadius = 15;
        b.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:13];
        [b setTitle:d[@"title"] forState:UIControlStateNormal];
        [b addTarget:self action:@selector(btn:) forControlEvents:UIControlEventTouchUpInside];
        [_pill addSubview:b]; [_buttons addObject:b];
    }
}
- (void)btn:(UIButton *)b {
    NSDictionary *d = _cur.buttons[b.tag];
    [[S15Core shared] performAction:d[@"action"] args:d[@"args"]];
    [self armTimer];
}
- (void)setExpanded:(BOOL)ex animated:(BOOL)anim fromHidden:(BOOL)fromHidden {
    CGRect old = fromHidden ? [self frameForExpanded:NO] : _pill.frame;
    if (fromHidden) old = CGRectInset(old, old.size.width * 0.35f, old.size.height * 0.35f);
    _expanded = ex;
    CGRect nf = [self frameForExpanded:ex];
    [self layoutContentExpanded:ex];
    _pill.frame = nf;
    CGFloat cr = ex ? 26 : nf.size.height / 2;
    if (anim && S15Pref(@"animations", YES)) {
        CGPoint oc = CGPointMake(CGRectGetMidX(old), CGRectGetMidY(old)), nc = CGPointMake(CGRectGetMidX(nf), CGRectGetMidY(nf));
        S15SpringAnimate(_pill.layer, @"bounds", [NSValue valueWithCGRect:CGRectMake(0, 0, old.size.width, old.size.height)],
                         [NSValue valueWithCGRect:CGRectMake(0, 0, nf.size.width, nf.size.height)], 0.7, 0.58);
        S15SpringAnimate(_pill.layer, @"position", [NSValue valueWithCGPoint:oc], [NSValue valueWithCGPoint:nc], 0.7, 0.58);
        S15SpringAnimate(_pill.layer, @"cornerRadius", @(_pill.layer.cornerRadius), @(cr), 0.7, 0.7);
    } else _pill.layer.cornerRadius = cr;
    // содержимое: compact-элементы / expanded-элементы
    for (UIView *v in @[_title, _sub, _barBg]) v.alpha = 0;
    for (UIView *b in _buttons) b.alpha = 0;
    _lead.alpha = _trail.alpha = fromHidden ? 0 : 1;
    [UIView animateWithDuration:0.28 delay:ex ? 0.12 : 0 options:0 animations:^{
        _title.alpha = _sub.alpha = ex ? 1 : 0;
        _barBg.alpha = (ex && _cur.progress >= 0) ? 1 : 0;
        for (UIView *b in _buttons) b.alpha = ex ? 1 : 0;
        _lead.alpha = 1; _trail.alpha = ex ? 0 : 1;
    } completion:nil];
}
- (void)armTimer {
    [_timer invalidate]; _timer = nil;
    NSTimeInterval t = _cur.duration > 0 ? _cur.duration : (_expanded ? MAX(_cur.expandedDuration, 5) : 0);
    if (t > 0) _timer = [NSTimer scheduledTimerWithTimeInterval:t target:self selector:@selector(timeout) userInfo:nil repeats:NO];
}
- (void)timeout {
    if (_cur.duration > 0) [self dismissIdentifier:_cur.identifier];
    else if (_expanded) { [self setExpanded:NO animated:YES fromHidden:NO]; }
}
- (void)tapped {
    if (_expanded && _cur.tapAction) { [[S15Core shared] performAction:_cur.tapAction args:nil]; [self setExpanded:NO animated:YES fromHidden:NO]; }
    else [self setExpanded:!_expanded animated:YES fromHidden:NO];
    [self armTimer];
}
- (void)swiped { if (_expanded) { [self setExpanded:NO animated:YES fromHidden:NO]; [self armTimer]; } }

- (void)dismissIdentifier:(NSString *)ident {
    if (![NSThread isMainThread]) { dispatch_async(dispatch_get_main_queue(), ^{ [self dismissIdentifier:ident]; }); return; }
    if (_cur && [_cur.identifier isEqual:ident]) {
        [_timer invalidate]; _timer = nil;
        _cur = nil;
        S15IslandActivity *prev = [_stack lastObject];
        if (prev) { [_stack removeLastObject]; [self present:prev]; return; }
        [UIView animateWithDuration:0.22 animations:^{ _pill.alpha = 0; _pill.transform = CGAffineTransformMakeScale(0.5f, 0.5f); }
                         completion:^(BOOL f) { if (!_cur) _win.hidden = YES; _pill.alpha = 1; _pill.transform = CGAffineTransformIdentity; }];
    } else {
        for (S15IslandActivity *a in [_stack copy]) if ([a.identifier isEqual:ident]) [_stack removeObject:a];
    }
}
@end

#pragma mark - Источники событий (SpringBoard)
static void S15MediaChanged(void) {
    id mc = [%c(SBMediaController) sharedInstance];
    NSString *t = [mc nowPlayingTitle];
    if (!S15Pref(@"islandMedia", YES)) return;
    if (!t.length) { [[S15Island shared] dismissIdentifier:@"media"]; return; }
    S15IslandActivity *a = [S15IslandActivity new];
    a.identifier = @"media"; a.leading = @"\u266B"; a.trailing = [mc isPlaying] ? @"\u275A\u275A" : @"\u25B6";
    a.title = t; a.subtitle = [mc nowPlayingArtist] ?: @"";
    a.accent = [UIColor colorWithRed:1 green:0.23f blue:0.36f alpha:1];
    a.expandedDuration = 3.5;
    a.buttons = @[@{@"title": @"\u25C0\u25C0", @"action": @"media.prev"},
                  @{@"title": @"\u25B6 \u275A\u275A", @"action": @"media.toggle"},
                  @{@"title": @"\u25B6\u25B6", @"action": @"media.next"}];
    [[S15Island shared] present:a];
}
static void S15BatteryChanged(void) {
    UIDevice *d = [UIDevice currentDevice];
    if (!S15Pref(@"islandCharging", YES)) return;
    if (d.batteryState == UIDeviceBatteryStateCharging) {
        S15IslandActivity *a = [S15IslandActivity new];
        a.identifier = @"charge"; a.leading = @"\u26A1";
        a.title = @"Идёт зарядка";
        a.subtitle = [NSString stringWithFormat:@"%d%%", (int)roundf(d.batteryLevel * 100)];
        a.progress = d.batteryLevel; a.accent = [UIColor colorWithRed:0.19f green:0.82f blue:0.35f alpha:1];
        a.duration = 3.0;
        [[S15Island shared] present:a];
    }
}
static void S15RingerChanged(void) {
    if (!S15Pref(@"islandRinger", YES)) return;
    BOOL muted = [[%c(SBMediaController) sharedInstance] isRingerMuted];
    S15IslandActivity *a = [S15IslandActivity new];
    a.identifier = @"ringer"; a.leading = muted ? @"\U0001F515" : @"\U0001F514";
    a.title = muted ? @"Без звука" : @"Звонок";
    a.accent = muted ? [UIColor colorWithRed:1 green:0.62f blue:0.04f alpha:1] : S15Blue();
    a.duration = 2.0;
    [[S15Island shared] present:a];
}

%group IslandSB
%hook BBServer
- (void)publishBulletin:(id)b destinations:(unsigned)d {
    %orig;
    if (!S15Pref(@"islandNotifications", YES)) return;
    @try {
        NSString *title = [b valueForKey:@"title"], *msg = [b valueForKey:@"message"];
        if (!title.length && !msg.length) return;
        S15IslandActivity *a = [S15IslandActivity new];
        a.identifier = @"notif"; a.leading = @"\U0001F4AC";
        a.title = title.length ? title : @"Уведомление"; a.subtitle = msg;
        a.duration = 4.0;
        [[S15Island shared] present:a];
    } @catch (NSException *e) {}
}
%end
%end

%ctor {
    if (!S15IsSpringBoard()) return;
    %init(IslandSB);
    S15Core *c = [S15Core shared];
    [c registerAction:@"media.prev"   handler:^(NSDictionary *a) { [[%c(SBMediaController) sharedInstance] changeTrack:-1]; }];
    [c registerAction:@"media.next"   handler:^(NSDictionary *a) { [[%c(SBMediaController) sharedInstance] changeTrack:1]; }];
    [c registerAction:@"media.toggle" handler:^(NSDictionary *a) { [[%c(SBMediaController) sharedInstance] togglePlayPause]; }];
    [c registerAction:@"island.test"  handler:^(NSDictionary *a) {
        S15IslandActivity *t = [S15IslandActivity new];
        t.identifier = @"test"; t.leading = @"\u2728"; t.title = @"style15"; t.subtitle = @"Dynamic Island работает";
        t.progress = 0.66f; t.duration = 3; [[S15Island shared] present:t];
    }];

    [UIDevice currentDevice].batteryMonitoringEnabled = YES;
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    void (^mediaBlock)(NSNotification *) = ^(NSNotification *n) { S15MediaChanged(); };
    [nc addObserverForName:@"SBMediaNowPlayingChangedNotification" object:nil queue:[NSOperationQueue mainQueue] usingBlock:mediaBlock];
    [nc addObserverForName:@"SBMediaPlayingChangedNotification" object:nil queue:[NSOperationQueue mainQueue] usingBlock:mediaBlock];
    [nc addObserverForName:UIDeviceBatteryStateDidChangeNotification object:nil queue:[NSOperationQueue mainQueue]
                usingBlock:^(NSNotification *n) { S15BatteryChanged(); }];
    int tok;
    notify_register_dispatch("com.apple.springboard.ringerstate", &tok, dispatch_get_main_queue(), ^(int t) { S15RingerChanged(); });
}
