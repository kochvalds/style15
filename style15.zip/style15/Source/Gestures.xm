// Gestures: краевые жесты в стиле iOS 15. Привязка жест -> действие в /Library/Style15/Gestures.plist
// ⚠ Окно-перехватчик ловит касания только в узких зонах. Если на твоей 6.x касания у краёв
//   не доходят до SpringBoard при открытом приложении — замени на SBGestureRecognizer.
#import "Private.h"

static NSString *S15Gesture(NSString *key) {
    NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:@"/Library/Style15/Gestures.plist"];
    return d[key];
}
static void S15Run(NSString *key) {
    NSString *act = S15Gesture(key);
    if (act.length && ![act isEqualToString:@"none"]) [[S15Core shared] performAction:act args:nil];
}

@interface S15EdgeWindow : UIWindow
@end
@implementation S15EdgeWindow {
    CGPoint _p0; NSTimeInterval _t0; int _zone;   // 1=низ, 2=верх-право
}
- (int)zoneAt:(CGPoint)p {
    CGSize s = self.bounds.size;
    if (p.y > s.height - 20) return 1;
    if (p.y < 20 && p.x > s.width * 0.62f) return 2;
    return 0;
}
- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent *)e { return [self zoneAt:p] != 0; }
- (void)sendEvent:(UIEvent *)e {
    NSSet *touches = [e allTouches];
    UITouch *t = [touches anyObject];
    if (!t) return;
    CGPoint p = [t locationInView:self];
    switch (t.phase) {
        case UITouchPhaseBegan:  _p0 = p; _t0 = t.timestamp; _zone = [self zoneAt:p]; break;
        case UITouchPhaseEnded: {
            CGFloat dx = p.x - _p0.x, dy = p.y - _p0.y; NSTimeInterval dt = t.timestamp - _t0;
            if (_zone == 1) {
                if (dy < -60 && fabsf(dx) < fabsf(dy)) S15Run(dt > 0.45 || dy < -170 ? @"bottomHold" : @"bottomUp");
                else if (dx > 60 && fabsf(dy) < 40) S15Run(@"bottomRight");
                else if (dx < -60 && fabsf(dy) < 40) S15Run(@"bottomLeft");
            } else if (_zone == 2 && dy > 40) S15Run(@"topRightDown");
            _zone = 0; break;
        }
        default: break;
    }
}
@end

static S15EdgeWindow *gEdge;
static void S15UpdateEdge(void) {
    BOOL on = S15Pref(@"enabled", YES) && S15Pref(@"gestures", YES);
    if (on && !gEdge) {
        gEdge = [[S15EdgeWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        gEdge.windowLevel = 2400; gEdge.backgroundColor = [UIColor clearColor];
        gEdge.rootViewController = nil;
    }
    gEdge.hidden = !on;
}

%ctor {
    if (!S15IsSpringBoard()) return;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        S15UpdateEdge();
        [[S15Core shared] observeEvent:@"prefs.reload" handler:^(NSDictionary *i) { S15UpdateEdge(); }];
    });
}
