// StatusBar: статус-бар iOS 15 (время слева, индикаторы справа, центр свободен для острова).
// Работает в SpringBoard и во всех UIKit-приложениях. SpringBoard публикует состояние
// сети через Darwin notify, приложения читают его.
#import "Private.h"

#define TAG_SB 151403
#define SB_NOTIFY "ru.style15.sb.state"

static int gToken = 0;

// bits: 0-3 сигнал(0-4)  4-7 wifi(0-3)  8 wifi on  9 airplane
static uint64_t S15ReadState(void) {
    uint64_t s = 0;
    if (!gToken) notify_register_check(SB_NOTIFY, &gToken);
    notify_get_state(gToken, &s);
    return s;
}

@interface S15StatusBarView : UIView
@end
@implementation S15StatusBarView {
    NSTimer *_timer;
    NSDateFormatter *_fmt;
}
- (id)initWithFrame:(CGRect)f {
    if ((self = [super initWithFrame:f])) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        self.opaque = NO;
        _fmt = [NSDateFormatter new];
        [_fmt setDateFormat:[NSDateFormatter dateFormatFromTemplate:@"j:mm" options:0 locale:[NSLocale currentLocale]]];
        [UIDevice currentDevice].batteryMonitoringEnabled = YES;
    }
    return self;
}
- (void)willMoveToWindow:(UIWindow *)w {
    [super willMoveToWindow:w];
    [_timer invalidate]; _timer = nil;
    if (w) _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(tick) userInfo:nil repeats:YES];
}
- (void)tick { [self setNeedsDisplay]; }

- (UIColor *)ink {
    if (S15IsSpringBoard()) return [UIColor whiteColor];
    return [UIApplication sharedApplication].statusBarStyle == UIStatusBarStyleDefault
        ? [UIColor blackColor] : [UIColor whiteColor];
}

- (void)drawRect:(CGRect)r {
    CGContextRef c = UIGraphicsGetCurrentContext();
    UIColor *ink = [self ink];
    [ink setFill]; [ink setStroke];
    CGFloat W = self.bounds.size.width;

    // Время (слева, жирное)
    NSString *t = [_fmt stringFromDate:[NSDate date]];
    [t drawAtPoint:CGPointMake(16, 2) withFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:14.5f]];

    uint64_t st = S15ReadState();
    int bars = (int)(st & 0xF), wifi = (int)((st >> 4) & 0xF);
    BOOL wifiOn = (st >> 8) & 1, air = (st >> 9) & 1;

    CGFloat x = W - 14;

    // Батарея
    UIDevice *d = [UIDevice currentDevice];
    float lvl = d.batteryLevel < 0 ? 1.0f : d.batteryLevel;
    BOOL chg = d.batteryState == UIDeviceBatteryStateCharging || d.batteryState == UIDeviceBatteryStateFull;
    CGRect body = CGRectMake(x - 24, 5, 22, 10.5f);
    x = body.origin.x - 6;
    UIBezierPath *outline = [UIBezierPath bezierPathWithRoundedRect:body cornerRadius:3.2f];
    [[ink colorWithAlphaComponent:0.4f] setStroke];
    outline.lineWidth = 1.0f; [outline stroke];
    CGRect tip = CGRectMake(CGRectGetMaxX(body) + 1.2f, 8.2f, 1.6f, 4.2f);
    [[ink colorWithAlphaComponent:0.45f] setFill];
    [[UIBezierPath bezierPathWithRoundedRect:tip cornerRadius:0.8f] fill];
    UIColor *fill = chg ? [UIColor colorWithRed:0.19f green:0.82f blue:0.35f alpha:1]
                 : (lvl <= 0.2f ? [UIColor colorWithRed:1 green:0.23f blue:0.19f alpha:1] : ink);
    [fill setFill];
    CGRect inner = CGRectInset(body, 1.6f, 1.6f);
    inner.size.width *= MAX(lvl, 0.05f);
    [[UIBezierPath bezierPathWithRoundedRect:inner cornerRadius:1.8f] fill];

    // Wi‑Fi
    if (wifiOn && !air) {
        CGPoint o = CGPointMake(x - 8, 16);
        x -= 20;
        for (int i = 1; i <= 3; i++) {
            CGFloat rad = i * 3.4f;
            [(i <= wifi ? ink : [ink colorWithAlphaComponent:0.3f]) setStroke];
            CGContextSetLineWidth(c, 2.0f);
            CGContextAddArc(c, o.x, o.y, rad, -M_PI * 0.75, -M_PI * 0.25, 0);
            CGContextStrokePath(c);
        }
        [ink setFill];
        CGContextFillEllipseInRect(c, CGRectMake(o.x - 1.2f, o.y - 1.2f, 2.4f, 2.4f));
    }

    // Сигнал
    if (!air) {
        for (int i = 3; i >= 0; i--) {
            CGFloat h = 4 + i * 2.6f;
            [(i < bars ? ink : [ink colorWithAlphaComponent:0.3f]) setFill];
            CGRect b = CGRectMake(x - 3.2f * (4 - i) - 1, 16 - h, 2.4f, h);
            [[UIBezierPath bezierPathWithRoundedRect:b cornerRadius:0.8f] fill];
        }
    } else {
        [@"\u2708" drawAtPoint:CGPointMake(x - 18, 2) withFont:[UIFont systemFontOfSize:13]];
    }
}
@end

static void S15Publish(void) {   // SpringBoard: собираем состояние сети и раздаём всем процессам
    static int tok = 0;
    if (!tok) notify_register_check(SB_NOTIFY, &tok);
    int bars = 0, wifi = 0; BOOL wOn = NO, air = NO;
    id tm = [%c(SBTelephonyManager) sharedTelephonyManager];
    id wm = [%c(SBWiFiManager) sharedInstance];
    if ([tm respondsToSelector:@selector(signalStrengthBars)]) bars = [tm signalStrengthBars];
    if ([tm respondsToSelector:@selector(isInAirplaneMode)]) air = [tm isInAirplaneMode];
    if ([wm respondsToSelector:@selector(wiFiEnabled)]) wOn = [wm wiFiEnabled];
    if ([wm respondsToSelector:@selector(signalStrengthBars)]) wifi = [wm signalStrengthBars];
    uint64_t s = (bars & 0xF) | ((uint64_t)(wifi & 0xF) << 4) | ((uint64_t)wOn << 8) | ((uint64_t)air << 9);
    uint64_t old = 0; notify_get_state(tok, &old);
    if (old != s) { notify_set_state(tok, s); notify_post(SB_NOTIFY); }
}

%group StatusBarUI
%hook UIStatusBar
- (void)layoutSubviews {
    %orig;
    UIView *mine = [self viewWithTag:TAG_SB];
    if (!S15Pref(@"enabled", YES) || !S15Pref(@"statusBar", YES)) {
        mine.hidden = YES;
        for (UIView *v in self.subviews) if (v.tag != TAG_SB) v.alpha = 1;
        return;
    }
    if (!mine) { mine = [[S15StatusBarView alloc] initWithFrame:self.bounds]; mine.tag = TAG_SB; [self addSubview:mine]; }
    mine.hidden = NO;
    mine.frame = self.bounds;
    for (UIView *v in self.subviews) {
        if (v.tag == TAG_SB) continue;
        if ([NSStringFromClass([v class]) rangeOfString:@"Foreground"].location != NSNotFound) v.alpha = 0;
    }
    [self bringSubviewToFront:mine];
}
%end
%end

%ctor {
    @autoreleasepool {
        %init(StatusBarUI);
        if (S15IsSpringBoard()) {
            [NSTimer scheduledTimerWithTimeInterval:2.0 target:[NSBlockOperation blockOperationWithBlock:^{ S15Publish(); }]
                                           selector:@selector(main) userInfo:nil repeats:YES];
        }
    }
}
