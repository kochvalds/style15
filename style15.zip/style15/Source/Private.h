// Объявления приватных классов iOS 6 (сверяй class-dump'ом под свою 6.x)
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <notify.h>
#import "Style15API.h"

@interface SBUIController : NSObject
+ (id)sharedInstance;
- (void)clickedMenuButton;
- (void)_toggleSwitcher;
@end
@interface SBAwayController : NSObject
+ (id)sharedAwayController;
- (void)unlockWithSound:(BOOL)sound;
- (void)attemptUnlock;
- (void)activateCamera;
@end
@interface SBMediaController : NSObject
+ (id)sharedInstance;
- (NSString *)nowPlayingTitle;
- (NSString *)nowPlayingArtist;
- (BOOL)isPlaying;
- (BOOL)isRingerMuted;
- (BOOL)togglePlayPause;
- (BOOL)changeTrack:(int)delta;
@end
@interface SBTelephonyManager : NSObject
+ (id)sharedTelephonyManager;
- (BOOL)isInAirplaneMode;
- (void)setIsInAirplaneMode:(BOOL)on;
- (int)signalStrengthBars;
@end
@interface SBWiFiManager : NSObject
+ (id)sharedInstance;
- (BOOL)wiFiEnabled;
- (void)setWiFiEnabled:(BOOL)on;
- (int)signalStrengthBars;
@end
@interface BluetoothManager : NSObject
+ (id)sharedInstance;
- (BOOL)enabled;
- (void)setEnabled:(BOOL)on;
@end
@interface SBOrientationLockManager : NSObject
+ (id)sharedInstance;
- (BOOL)isLocked;
- (void)lock;
- (void)unlock;
@end
@interface SBScreenShotter : NSObject
+ (id)sharedInstance;
- (void)saveScreenshot:(BOOL)flash;
@end
@interface SBNotificationCenterController : NSObject
+ (id)sharedInstance;
- (void)presentAnimated:(BOOL)a;
@end
@interface SBIconController : NSObject
+ (id)sharedInstance;
- (void)scrollToIconListAtIndex:(int)i animate:(BOOL)a;
- (BOOL)isEditing;
- (UIView *)contentView;
@end
@interface SpringBoard : UIApplication
- (BOOL)launchApplicationWithIdentifier:(NSString *)ident suspended:(BOOL)s;
@end
@interface AVSystemController : NSObject
+ (id)sharedAVSystemController;
- (BOOL)getVolume:(float *)v forCategory:(NSString *)c;
- (BOOL)setVolumeTo:(float)v forCategory:(NSString *)c;
@end

// Утилиты из Core.xm
BOOL S15Try(id obj, NSArray *selectorNames);
void S15Torch(void);
UIColor *S15Blue(void);
