// Control Center: свой Пункт управления (в iOS 6 его нет). Открывается жестом или действием "controlCenter".
#import "Private.h"

#pragma mark - Вертикальный слайдер
@interface S15VSlider : UIView
@property (nonatomic, assign) CGFloat value;
@property (nonatomic, copy) void (^onChange)(CGFloat v);
@property (nonatomic, copy) NSString *glyph;
@end
@implementation S15VSlider
- (id)initWithFrame:(CGRect)f {
    if ((self = [super initWithFrame:f])) {
        self.backgroundColor = [UIColor colorWithWhite:1 alpha:0.18f];
        self.layer.cornerRadius = 24; self.clipsToBounds = YES;
    }
    return self;
}
- (void)setValue:(CGFloat)v { _value = MAX(0, MIN(1, v)); [self setNeedsDisplay]; }
- (void)drawRect:(CGRect)r {
    CGFloat h = self.bounds.size.height * _value;
    [[UIColor colorWithWhite:1 alpha:0.92f] setFill];
    UIRectFill(CGRectMake(0, self.bounds.size.height - h, self.bounds.size.width, h));
    [[UIColor colorWithWhite:0.35f alpha:0.9f] set];
    [_glyph drawInRect:CGRectMake(0, self.bounds.size.height - 34, self.bounds.size.width, 28)
              withFont:[UIFont systemFontOfSize:20] lineBreakMode:UILineBreakModeClip alignment:UITextAlignmentCenter];
}
- (void)touch:(NSSet *)t {
    CGFloat y = [[t anyObject] locationInView:self].y;
    self.value = 1 - y / self.bounds.size.height;
    if (_onChange) _onChange(_value);
}
- (void)touchesBegan:(NSSet *)t withEvent:(UIEvent *)e { [self touch:t]; }
- (void)touchesMoved:(NSSet *)t withEvent:(UIEvent *)e { [self touch:t]; }
@end

#pragma mark - Окно ЦУ
@interface S15CCWindow : UIWindow
@end
@implementation S15CCWindow
@end

@interface S15CC : NSObject
+ (instancetype)shared;
- (void)toggle;
@end

@implementation S15CC {
    S15CCWindow *_win;
    UIView *_dim, *_panel;
    UIButton *_air, *_wifi, *_bt, *_rot, *_torchBtn;
    UILabel *_mTitle, *_mArtist;
    S15VSlider *_bright, *_vol;
    BOOL _shown;
}
+ (instancetype)shared { static S15CC *c; static dispatch_once_t o; dispatch_once(&o, ^{ c = [S15CC new]; }); return c; }

- (UIButton *)round:(NSString *)t frame:(CGRect)f tag:(int)tag sel:(SEL)s {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.frame = f; b.tag = tag;
    b.backgroundColor = [UIColor colorWithWhite:1 alpha:0.18f];
    b.layer.cornerRadius = f.size.height / 2;
    b.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:t.length > 2 ? 12 : 22];
    [b setTitle:t forState:UIControlStateNormal];
    [b addTarget:self action:s forControlEvents:UIControlEventTouchUpInside];
    return b;
}
- (UIView *)block:(CGRect)f {
    UIView *v = [[UIView alloc] initWithFrame:f];
    v.backgroundColor = [UIColor colorWithWhite:1 alpha:0.16f];
    v.layer.cornerRadius = 24;
    return v;
}
- (void)build {
    CGRect sc = [UIScreen mainScreen].bounds;
    _win = [[S15CCWindow alloc] initWithFrame:sc];
    _win.windowLevel = 2501; _win.backgroundColor = [UIColor clearColor];

    _dim = [[UIView alloc] initWithFrame:sc];
    _dim.backgroundColor = [UIColor colorWithWhite:0 alpha:0.55f];
    [_dim addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggle)]];
    UISwipeGestureRecognizer *up = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(toggle)];
    up.direction = UISwipeGestureRecognizerDirectionUp; [_dim addGestureRecognizer:up];
    [_win addSubview:_dim];

    CGFloat m = 16, bw = (sc.size.width - m * 3) / 2, bh = 144;
    _panel = [[UIView alloc] initWithFrame:CGRectMake(0, 36, sc.size.width, bh * 2 + m)];
    [_win addSubview:_panel];

    // 1: связь
    UIView *b1 = [self block:CGRectMake(m, 0, bw, bh)]; [_panel addSubview:b1];
    CGFloat s = 56, g = (bw - s * 2) / 3;
    _air  = [self round:@"\u2708" frame:CGRectMake(g, g, s, s) tag:1 sel:@selector(toggleAir)];
    _wifi = [self round:@"Wi‑Fi" frame:CGRectMake(g * 2 + s, g, s, s) tag:2 sel:@selector(toggleWifi)];
    _bt   = [self round:@"BT" frame:CGRectMake(g, g * 2 + s, s, s) tag:3 sel:@selector(toggleBT)];
    _rot  = [self round:@"\u21BB" frame:CGRectMake(g * 2 + s, g * 2 + s, s, s) tag:4 sel:@selector(toggleRot)];
    for (UIButton *b in @[_air, _wifi, _bt, _rot]) [b1 addSubview:b];

    // 2: музыка
    UIView *b2 = [self block:CGRectMake(m * 2 + bw, 0, bw, bh)]; [_panel addSubview:b2];
    _mTitle = [[UILabel alloc] initWithFrame:CGRectMake(12, 16, bw - 24, 20)];
    _mTitle.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:15];
    _mArtist = [[UILabel alloc] initWithFrame:CGRectMake(12, 38, bw - 24, 18)];
    _mArtist.font = [UIFont fontWithName:@"HelveticaNeue" size:13];
    for (UILabel *l in @[_mTitle, _mArtist]) { l.backgroundColor = [UIColor clearColor]; l.textColor = [UIColor colorWithWhite:1 alpha:0.9f]; [b2 addSubview:l]; }
    NSArray *tt = @[@"\u25C0\u25C0", @"\u25B6\u275A", @"\u25B6\u25B6"];
    SEL ss[] = { @selector(prev), @selector(play), @selector(next) };
    for (int i = 0; i < 3; i++) {
        UIButton *b = [self round:tt[i] frame:CGRectMake(8 + i * ((bw - 16) / 3), bh - 56, (bw - 16) / 3 - 6, 40) tag:10 + i sel:ss[i]];
        b.backgroundColor = [UIColor clearColor]; b.titleLabel.font = [UIFont systemFontOfSize:15];
        [b2 addSubview:b];
    }

    // 3: быстрые действия
    UIView *b3 = [self block:CGRectMake(m, bh + m, bw, bh)]; [_panel addSubview:b3];
    NSArray *quick = @[@"\u2600", @"\u25CE", @"\u23F1", @"\u2699"];
    SEL qs[] = { @selector(torch), @selector(camera), @selector(clock), @selector(settings) };
    for (int i = 0; i < 4; i++) {
        UIButton *b = [self round:quick[i] frame:CGRectMake(g + (i % 2) * (s + g), g + (i / 2) * (s + g), s, s) tag:20 + i sel:qs[i]];
        if (i == 0) _torchBtn = b;
        [b3 addSubview:b];
    }

    // 4: слайдеры
    CGFloat sw = (bw - 12) / 2;
    _bright = [[S15VSlider alloc] initWithFrame:CGRectMake(m * 2 + bw, bh + m, sw, bh)];
    _bright.glyph = @"\u2600";
    _bright.onChange = ^(CGFloat v) { [UIScreen mainScreen].brightness = v; };
    _vol = [[S15VSlider alloc] initWithFrame:CGRectMake(m * 2 + bw + sw + 12, bh + m, sw, bh)];
    _vol.glyph = @"\u266B";
    _vol.onChange = ^(CGFloat v) {
        id sys = [NSClassFromString(@"AVSystemController") sharedAVSystemController];
        [sys setVolumeTo:v forCategory:@"Audio/Video"];
    };
    [_panel addSubview:_bright]; [_panel addSubview:_vol];
}
- (void)tint:(UIButton *)b on:(BOOL)on color:(UIColor *)c {
    [UIView animateWithDuration:0.2 animations:^{ b.backgroundColor = on ? c : [UIColor colorWithWhite:1 alpha:0.18f]; }];
}
- (void)refresh {
    id tm = [%c(SBTelephonyManager) sharedTelephonyManager];
    id wm = [%c(SBWiFiManager) sharedInstance];
    [self tint:_air on:[tm respondsToSelector:@selector(isInAirplaneMode)] && [tm isInAirplaneMode] color:[UIColor colorWithRed:1 green:0.62f blue:0.04f alpha:1]];
    [self tint:_wifi on:[wm respondsToSelector:@selector(wiFiEnabled)] && [wm wiFiEnabled] color:S15Blue()];
    id bm = [NSClassFromString(@"BluetoothManager") sharedInstance];
    [self tint:_bt on:[bm respondsToSelector:@selector(enabled)] && [bm enabled] color:S15Blue()];
    id ol = [%c(SBOrientationLockManager) sharedInstance];
    [self tint:_rot on:[ol respondsToSelector:@selector(isLocked)] && [ol isLocked] color:[UIColor colorWithRed:1 green:0.23f blue:0.19f alpha:1]];
    _bright.value = [UIScreen mainScreen].brightness;
    float v = 0.5f; id sys = [NSClassFromString(@"AVSystemController") sharedAVSystemController];
    if ([sys respondsToSelector:@selector(getVolume:forCategory:)]) [sys getVolume:&v forCategory:@"Audio/Video"];
    _vol.value = v;
    id mc = [%c(SBMediaController) sharedInstance];
    _mTitle.text = [mc nowPlayingTitle] ?: @"Не воспроизводится";
    _mArtist.text = [mc nowPlayingArtist];
}
- (void)toggleAir { id t = [%c(SBTelephonyManager) sharedTelephonyManager]; [t setIsInAirplaneMode:![t isInAirplaneMode]]; [self refresh]; }
- (void)toggleWifi { id w = [%c(SBWiFiManager) sharedInstance]; [w setWiFiEnabled:![w wiFiEnabled]]; [self refresh]; }
- (void)toggleBT { id b = [NSClassFromString(@"BluetoothManager") sharedInstance]; [b setEnabled:![b enabled]]; [self refresh]; }
- (void)toggleRot { id o = [%c(SBOrientationLockManager) sharedInstance]; [o isLocked] ? [o unlock] : [o lock]; [self refresh]; }
- (void)prev { [[%c(SBMediaController) sharedInstance] changeTrack:-1]; }
- (void)next { [[%c(SBMediaController) sharedInstance] changeTrack:1]; }
- (void)play { [[%c(SBMediaController) sharedInstance] togglePlayPause]; [self performSelector:@selector(refresh) withObject:nil afterDelay:0.3]; }
- (void)torch { S15Torch(); }
- (void)launch:(NSString *)bid { [self toggle]; [[S15Core shared] performAction:@"launch" args:@{@"bundle": bid}]; }
- (void)camera { [self launch:@"com.apple.camera"]; }
- (void)clock { [self launch:@"com.apple.mobiletimer"]; }
- (void)settings { [self launch:@"com.apple.Preferences"]; }

- (void)toggle {
    if (!_win) [self build];
    if (!_shown) {
        [self refresh];
        _win.hidden = NO; _shown = YES;
        _dim.alpha = 0; _panel.alpha = 0;
        [UIView animateWithDuration:0.25 animations:^{ _dim.alpha = 1; _panel.alpha = 1; }];
        S15SpringAnimate(_panel.layer, @"position.y", @(_panel.layer.position.y - 60), @(_panel.layer.position.y), 0.65, 0.6);
        S15SpringAnimate(_panel.layer, @"transform.scale", @0.92, @1.0, 0.65, 0.6);
        [[S15Core shared] postEvent:@"cc.shown" info:nil];
    } else {
        _shown = NO;
        [UIView animateWithDuration:0.22 animations:^{ _dim.alpha = 0; _panel.alpha = 0; _panel.transform = CGAffineTransformMakeScale(0.94f, 0.94f); }
                         completion:^(BOOL f) { if (!_shown) { _win.hidden = YES; _panel.transform = CGAffineTransformIdentity; } }];
    }
}
@end

%ctor {
    if (S15IsSpringBoard()) {
        [[S15Core shared] registerAction:@"controlCenter" handler:^(NSDictionary *a) {
            if (S15Pref(@"controlCenter", YES)) [[S15CC shared] toggle];
        }];
    }
}
