// Home: иконки, подписи, бейджи, папки, док, Search-pill, анимации нажатий, обои
#import "Private.h"

#define TAG_DOCK 151401
#define TAG_PILL 151402
#define TAG_WALL 151409

static BOOL On(void) { return S15Pref(@"enabled", YES); }

@interface S15PillTarget : NSObject
+ (void)tap;
@end
@implementation S15PillTarget
+ (void)tap { [[S15Core shared] performAction:@"spotlight" args:nil]; }
@end

static UIView *S15MakePlate(CGRect f) {
    UIView *p = [[UIView alloc] initWithFrame:f];
    p.tag = TAG_DOCK;
    p.userInteractionEnabled = NO;
    p.backgroundColor = [UIColor colorWithWhite:1.0f alpha:0.26f];
    p.layer.cornerRadius = 26.0f;
    p.layer.borderWidth = 0.5f;
    p.layer.borderColor = [UIColor colorWithWhite:1.0f alpha:0.18f].CGColor;
    return p;
}

static void S15Release(UIView *v) {
    if (CGAffineTransformIsIdentity(v.transform)) return;
    v.transform = CGAffineTransformIdentity;
    S15SpringAnimate(v.layer, @"transform.scale", @0.90, @1.0, 0.55, 0.45);
}

%group Home

#pragma mark Иконки
%hook SBIconImageView
- (void)layoutSubviews {
    %orig;
    if (!On()) return;
    CGFloat w = self.bounds.size.width;
    if (w <= 0) return;
    self.layer.cornerRadius = w * 0.2237f;
    self.layer.masksToBounds = YES;
    self.layer.shadowOpacity = 0;
    for (UIView *v in self.subviews) {
        NSString *n = NSStringFromClass([v class]);
        if ([n rangeOfString:@"Shine"].location != NSNotFound ||
            [n rangeOfString:@"Gloss"].location != NSNotFound ||
            [n rangeOfString:@"Overlay"].location != NSNotFound) v.hidden = YES;
    }
}
%end

#pragma mark Папки: полупрозрачная плашка
%hook SBFolderIconImageView
- (void)layoutSubviews {
    %orig;
    if (!On()) return;
    self.backgroundColor = [UIColor colorWithWhite:1.0f alpha:0.28f];
}
%end

#pragma mark Нажатие иконки: пружинный «push»
%hook SBIconView
- (void)touchesBegan:(NSSet *)t withEvent:(UIEvent *)e {
    %orig;
    if (On() && S15Pref(@"animations", YES) && ![[%c(SBIconController) sharedInstance] isEditing])
        [UIView animateWithDuration:0.10 delay:0 options:UIViewAnimationOptionAllowUserInteraction
                         animations:^{ self.transform = CGAffineTransformMakeScale(0.90f, 0.90f); } completion:nil];
}
- (void)touchesEnded:(NSSet *)t withEvent:(UIEvent *)e   { %orig; S15Release(self); }
- (void)touchesCancelled:(NSSet *)t withEvent:(UIEvent *)e { %orig; S15Release(self); }
%end

#pragma mark Подписи
%hook SBIconLabelImageParameters
- (UIFont *)font { return On() ? [UIFont fontWithName:@"HelveticaNeue-Medium" size:11.5f] : %orig; }
- (UIColor *)shadowColor { return On() ? nil : %orig; }
%end

#pragma mark Бейджи
%hook SBIconBadgeView
- (void)layoutSubviews {
    %orig;
    if (!On() || !S15Pref(@"flatBadges", YES)) return;
    for (UIView *v in self.subviews) if ([v isKindOfClass:[UIImageView class]]) v.hidden = YES;
    self.backgroundColor = [UIColor colorWithRed:1.0f green:0.231f blue:0.188f alpha:1.0f];
    self.layer.cornerRadius = self.bounds.size.height / 2.0f;
    self.layer.masksToBounds = YES;
}
%end

#pragma mark Док + pill + обои
%hook SBDockView
- (void)layoutSubviews {
    %orig;
    UIView *plate = [self viewWithTag:TAG_DOCK];
    UIView *host  = self.superview;
    UIView *pill  = [host viewWithTag:TAG_PILL];

    if (!On()) { plate.hidden = YES; pill.hidden = YES; return; }

    if (S15Pref(@"floatingDock", YES)) {
        for (UIView *v in self.subviews) {
            if (v.tag == TAG_DOCK) continue;
            NSString *n = NSStringFromClass([v class]);
            if ([n rangeOfString:@"Background"].location != NSNotFound ||
                [n rangeOfString:@"Shadow"].location != NSNotFound) v.hidden = YES;
        }
        CGRect f = CGRectMake(10, 8, self.bounds.size.width - 20, self.bounds.size.height - 16);
        if (!plate) {
            plate = S15MakePlate(f);
            [self insertSubview:plate atIndex:0];
            if (S15Pref(@"animations", YES)) {   // появление пружиной
                S15SpringAnimate(plate.layer, @"transform.scale", @0.92, @1.0, 0.6, 0.55);
            }
        }
        plate.frame = f;
        plate.hidden = NO;
    } else plate.hidden = YES;

    if (S15Pref(@"searchPill", YES) && host) {
        CGFloat w = 112, h = 30;
        CGRect pf = CGRectMake((host.bounds.size.width - w) / 2.0f, self.frame.origin.y - h - 6, w, h);
        if (!pill) {
            UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
            b.tag = TAG_PILL;
            b.backgroundColor = [UIColor colorWithWhite:1.0f alpha:0.22f];
            b.layer.cornerRadius = h / 2.0f;
            b.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Medium" size:13];
            [b setTitle:@"\u2315  Search" forState:UIControlStateNormal];
            [b setTitleColor:[UIColor colorWithWhite:1 alpha:0.92f] forState:UIControlStateNormal];
            [b addTarget:[S15PillTarget class] action:@selector(tap) forControlEvents:UIControlEventTouchUpInside];
            [host addSubview:b];
            pill = b;
        }
        pill.frame = pf;
        pill.hidden = NO;
    } else pill.hidden = YES;

    // Обои (по желанию): /Library/Style15/Wallpapers/default.png
    if (host && S15Pref(@"wallpaper", NO)) {
        UIImageView *wp = (UIImageView *)[host viewWithTag:TAG_WALL];
        if (!wp) {
            UIImage *img = [UIImage imageWithContentsOfFile:@"/Library/Style15/Wallpapers/default.png"];
            if (img) {
                wp = [[UIImageView alloc] initWithImage:img];
                wp.tag = TAG_WALL;
                wp.contentMode = UIViewContentModeScaleAspectFill;
                wp.clipsToBounds = YES;
                wp.userInteractionEnabled = NO;
                [host insertSubview:wp atIndex:0];
            }
        }
        wp.frame = host.bounds;
    }
}
%end

%hook SBIconPageControl
- (void)layoutSubviews {
    %orig;
    self.alpha = (On() && S15Pref(@"searchPill", YES)) ? 0.0f : 1.0f;
}
%end

%end // group Home

%ctor {
    if (S15IsSpringBoard()) %init(Home);
}
