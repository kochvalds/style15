// LockScreen: большие часы, дата, фонарик/камера, «swipe up to unlock» с пружиной
#import "Private.h"

#define TAG_LOCK 151404

@interface S15LockOverlay : UIView
@end
@implementation S15LockOverlay {
    UILabel *_date, *_time;
    UIButton *_torch, *_cam;
    UIView *_bar;
    NSTimer *_timer;
    NSDateFormatter *_df, *_tf;
    CGFloat _startY;
}
- (id)initWithFrame:(CGRect)f {
    if ((self = [super initWithFrame:f])) {
        self.backgroundColor = [UIColor clearColor];
        _df = [NSDateFormatter new]; [_df setDateFormat:@"EEEE, d MMMM"];
        _tf = [NSDateFormatter new];
        [_tf setDateFormat:[NSDateFormatter dateFormatFromTemplate:@"j:mm" options:0 locale:[NSLocale currentLocale]]];

        _date = [self label:17 weight:@"HelveticaNeue-Medium" alpha:0.85f];
        _time = [self label:92 weight:@"HelveticaNeue-Bold"   alpha:0.95f];
        _time.shadowColor = [UIColor colorWithWhite:0 alpha:0.12f];
        _time.shadowOffset = CGSizeMake(0, 1);

        _torch = [self circleButton:@"\u2600" action:@selector(torch)];   // фонарик
        _cam   = [self circleButton:@"\u25CE" action:@selector(camera)];  // камера

        _bar = [[UIView alloc] initWithFrame:CGRectZero];
        _bar.backgroundColor = [UIColor colorWithWhite:1 alpha:0.8f];
        _bar.layer.cornerRadius = 2.5f;
        [self addSubview:_bar];
    }
    return self;
}
- (UILabel *)label:(CGFloat)size weight:(NSString *)font alpha:(CGFloat)a {
    UILabel *l = [[UILabel alloc] init];
    l.backgroundColor = [UIColor clearColor];
    l.textAlignment = UITextAlignmentCenter;
    l.font = [UIFont fontWithName:font size:size];
    l.textColor = [UIColor colorWithWhite:1 alpha:a];
    l.adjustsFontSizeToFitWidth = YES;
    [self addSubview:l];
    return l;
}
- (UIButton *)circleButton:(NSString *)t action:(SEL)s {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.backgroundColor = [UIColor colorWithWhite:0 alpha:0.35f];
    b.layer.cornerRadius = 25;
    b.titleLabel.font = [UIFont systemFontOfSize:22];
    [b setTitle:t forState:UIControlStateNormal];
    [b addTarget:self action:s forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:b];
    return b;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat W = self.bounds.size.width, H = self.bounds.size.height;
    _date.frame = CGRectMake(0, 56, W, 24);
    _time.frame = CGRectMake(0, 74, W, 100);
    _torch.frame = CGRectMake(40, H - 130, 50, 50);
    _cam.frame   = CGRectMake(W - 90, H - 130, 50, 50);
    _bar.frame   = CGRectMake((W - 134) / 2, H - 20, 134, 5);
}
- (void)willMoveToWindow:(UIWindow *)w {
    [super willMoveToWindow:w];
    [_timer invalidate]; _timer = nil;
    if (w) { [self tick]; _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(tick) userInfo:nil repeats:YES]; }
}
- (void)tick { _time.text = [_tf stringFromDate:[NSDate date]]; _date.text = [_df stringFromDate:[NSDate date]]; }
- (void)torch  { [[S15Core shared] performAction:@"torch" args:nil]; }
- (void)camera { S15Try([%c(SBAwayController) sharedAwayController], @[@"activateCamera"]); }

// Принимаем касания только внизу и на кнопках — уведомления под нами остаются рабочими
- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent *)e {
    if (p.y > self.bounds.size.height - 90) return YES;
    return CGRectContainsPoint(_torch.frame, p) || CGRectContainsPoint(_cam.frame, p);
}
- (void)touchesBegan:(NSSet *)t withEvent:(UIEvent *)e { _startY = [[t anyObject] locationInView:self].y; }
- (void)touchesMoved:(NSSet *)t withEvent:(UIEvent *)e {
    CGFloat dy = MIN(0, [[t anyObject] locationInView:self].y - _startY);
    self.transform = CGAffineTransformMakeTranslation(0, dy * 0.6f);
    self.alpha = 1 + dy / 400.0f;
}
- (void)touchesEnded:(NSSet *)t withEvent:(UIEvent *)e {
    CGFloat dy = [[t anyObject] locationInView:self].y - _startY;
    if (dy < -90) {   // разблокировка
        id away = [%c(SBAwayController) sharedAwayController];
        if (!S15Try(away, @[@"attemptUnlock"])) [away unlockWithSound:YES];
        [UIView animateWithDuration:0.35 animations:^{
            self.transform = CGAffineTransformMakeTranslation(0, -80); self.alpha = 0;
        } completion:^(BOOL f) { self.transform = CGAffineTransformIdentity; self.alpha = 1; }];
    } else {
        self.transform = CGAffineTransformIdentity; self.alpha = 1;
        S15SpringAnimate(self.layer, @"position.y", @(self.layer.position.y + dy * 0.6f), @(self.layer.position.y), 0.5, 0.5);
    }
}
- (void)touchesCancelled:(NSSet *)t withEvent:(UIEvent *)e { [self touchesEnded:t withEvent:e]; }
@end

%group Lock
%hook SBAwayView
- (void)layoutSubviews {
    %orig;
    UIView *mine = [self viewWithTag:TAG_LOCK];
    if (!S15Pref(@"enabled", YES) || !S15Pref(@"lockScreen", YES)) { mine.hidden = YES; return; }
    for (UIView *v in self.subviews) {
        if (v.tag == TAG_LOCK) continue;
        NSString *n = NSStringFromClass([v class]);
        if ([n rangeOfString:@"LockBar"].location != NSNotFound ||
            [n rangeOfString:@"DateView"].location != NSNotFound ||
            [n rangeOfString:@"DateHeader"].location != NSNotFound) v.hidden = YES;
    }
    if (!mine) { mine = [[S15LockOverlay alloc] initWithFrame:self.bounds]; mine.tag = TAG_LOCK; [self addSubview:mine]; }
    mine.hidden = NO; mine.frame = self.bounds;
    [self bringSubviewToFront:mine];
}
%end
%end

%ctor { if (S15IsSpringBoard()) %init(Lock); }
