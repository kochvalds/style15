// Core: настройки, пружины, шина событий, реестр действий, загрузка модулей
#import "Private.h"
#import <AVFoundation/AVFoundation.h>

#define S15_DOMAIN CFSTR("ru.style15.launcher")

#pragma mark - Настройки
BOOL S15Pref(NSString *key, BOOL def) {
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)key, S15_DOMAIN);
    if (!v) return def;
    BOOL r = def;
    if (CFGetTypeID(v) == CFBooleanGetTypeID()) r = CFBooleanGetValue((CFBooleanRef)v);
    CFRelease(v);
    return r;
}
CGFloat S15PrefFloat(NSString *key, CGFloat def) {
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)key, S15_DOMAIN);
    if (!v) return def;
    CGFloat r = def;
    if (CFGetTypeID(v) == CFNumberGetTypeID()) { double d; CFNumberGetValue((CFNumberRef)v, kCFNumberDoubleType, &d); r = d; }
    CFRelease(v);
    return r;
}
BOOL S15IsSpringBoard(void) {
    static BOOL r, done;
    if (!done) { r = [[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.springboard"]; done = YES; }
    return r;
}
UIColor *S15Blue(void) { return [UIColor colorWithRed:0.039f green:0.518f blue:1.0f alpha:1.0f]; } // #0A84FF

BOOL S15Try(id obj, NSArray *names) {
    for (NSString *n in names) {
        SEL s = NSSelectorFromString(n);
        if (obj && [obj respondsToSelector:s]) { [obj performSelector:s]; return YES; }
    }
    return NO;
}

#pragma mark - Пружинная анимация (в iOS 6 нет spring API — считаем сами)
static CGFloat S15Spring(CGFloat t, CGFloat zeta, CGFloat duration) {
    CGFloat w0 = 2.0f * M_PI * 2.0f;
    CGFloat tau = t * duration;
    if (zeta >= 1.0f) return 1.0f - expf(-w0 * tau) * (1.0f + w0 * tau);
    CGFloat wd = w0 * sqrtf(1.0f - zeta * zeta);
    return 1.0f - expf(-zeta * w0 * tau) * (cosf(wd * tau) + (zeta * w0 / wd) * sinf(wd * tau));
}
static id S15Lerp(id a, id b, CGFloat p) {
    if ([a isKindOfClass:[NSNumber class]]) {
        CGFloat x = [a floatValue], y = [b floatValue];
        return @(x + (y - x) * p);
    }
    NSValue *va = a, *vb = b; const char *t = [va objCType];
    if (!strcmp(t, @encode(CGRect))) {
        CGRect x = [va CGRectValue], y = [vb CGRectValue];
        return [NSValue valueWithCGRect:CGRectMake(x.origin.x + (y.origin.x - x.origin.x) * p,
                                                    x.origin.y + (y.origin.y - x.origin.y) * p,
                                                    x.size.width + (y.size.width - x.size.width) * p,
                                                    x.size.height + (y.size.height - x.size.height) * p)];
    }
    if (!strcmp(t, @encode(CGPoint))) {
        CGPoint x = [va CGPointValue], y = [vb CGPointValue];
        return [NSValue valueWithCGPoint:CGPointMake(x.x + (y.x - x.x) * p, x.y + (y.y - x.y) * p)];
    }
    if (!strcmp(t, @encode(CGSize))) {
        CGSize x = [va CGSizeValue], y = [vb CGSizeValue];
        return [NSValue valueWithCGSize:CGSizeMake(x.width + (y.width - x.width) * p, x.height + (y.height - x.height) * p)];
    }
    return b;
}
void S15SpringAnimate(CALayer *layer, NSString *keyPath, id from, id to, CGFloat duration, CGFloat zeta) {
    const int N = 48;
    NSMutableArray *vals = [NSMutableArray arrayWithCapacity:N + 1];
    for (int i = 0; i <= N; i++) [vals addObject:S15Lerp(from, to, S15Spring((CGFloat)i / N, zeta, duration))];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    [layer setValue:to forKeyPath:keyPath];
    [CATransaction commit];
    CAKeyframeAnimation *a = [CAKeyframeAnimation animationWithKeyPath:keyPath];
    a.values = vals;
    a.duration = duration;
    a.calculationMode = kCAAnimationLinear;
    [layer addAnimation:a forKey:[@"s15." stringByAppendingString:keyPath]];
}

#pragma mark - Фонарик
void S15Torch(void) {
    AVCaptureDevice *d = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    if (![d hasTorch]) return;
    if ([d lockForConfiguration:nil]) {
        [d setTorchMode:([d torchMode] == AVCaptureTorchModeOn) ? AVCaptureTorchModeOff : AVCaptureTorchModeOn];
        [d unlockForConfiguration];
    }
}

#pragma mark - S15Core
@implementation S15Core {
    NSMutableDictionary *_actions;
    NSMutableDictionary *_events;
}
+ (instancetype)shared {
    static S15Core *c; static dispatch_once_t once;
    dispatch_once(&once, ^{ c = [S15Core new]; });
    return c;
}
- (id)init {
    if ((self = [super init])) { _actions = [NSMutableDictionary new]; _events = [NSMutableDictionary new]; }
    return self;
}
- (void)registerAction:(NSString *)name handler:(S15ActionHandler)h { if (name && h) _actions[name] = [h copy]; }
- (BOOL)performAction:(NSString *)name args:(NSDictionary *)args {
    S15ActionHandler h = _actions[name];
    if (!h) return NO;
    dispatch_async(dispatch_get_main_queue(), ^{ h(args ?: @{}); });
    return YES;
}
- (NSArray *)actionNames { return [[_actions allKeys] sortedArrayUsingSelector:@selector(compare:)]; }
- (void)observeEvent:(NSString *)name handler:(S15EventHandler)h {
    NSMutableArray *a = _events[name]; if (!a) _events[name] = a = [NSMutableArray new];
    [a addObject:[h copy]];
}
- (void)postEvent:(NSString *)name info:(NSDictionary *)info {
    for (S15EventHandler h in [_events[name] copy]) h(info ?: @{});
}
@end

#pragma mark - Встроенные действия (SpringBoard)
static void S15RegisterBuiltins(void) {
    S15Core *c = [S15Core shared];

    [c registerAction:@"home" handler:^(NSDictionary *a) {
        S15Try([%c(SBUIController) sharedInstance], @[@"clickedMenuButton"]);
    }];
    [c registerAction:@"switcher" handler:^(NSDictionary *a) {
        S15Try([%c(SBUIController) sharedInstance], @[@"_toggleSwitcher", @"activateSwitcher"]);
    }];
    [c registerAction:@"notificationCenter" handler:^(NSDictionary *a) {
        id nc = [%c(SBNotificationCenterController) sharedInstance];
        if ([nc respondsToSelector:@selector(presentAnimated:)]) [nc presentAnimated:YES];
    }];
    [c registerAction:@"screenshot" handler:^(NSDictionary *a) {
        id s = [%c(SBScreenShotter) sharedInstance];
        if ([s respondsToSelector:@selector(saveScreenshot:)]) [s saveScreenshot:YES];
    }];
    [c registerAction:@"torch" handler:^(NSDictionary *a) { S15Torch(); }];
    [c registerAction:@"spotlight" handler:^(NSDictionary *a) {
        S15Try([%c(SBUIController) sharedInstance], @[@"clickedMenuButton"]);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 300 * NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
            [[%c(SBIconController) sharedInstance] scrollToIconListAtIndex:-1 animate:YES];
        });
    }];
    [c registerAction:@"respring" handler:^(NSDictionary *a) { exit(0); }];
    [c registerAction:@"lock" handler:^(NSDictionary *a) {   // ⚠ проверь селектор на своей 6.x
        id away = [%c(SBAwayController) sharedAwayController];
        SEL s = NSSelectorFromString(@"lockDevice:");
        if ([away respondsToSelector:s])
            ((void (*)(id, SEL, double))objc_msgSend)(away, s, CACurrentMediaTime());
    }];
    [c registerAction:@"launch" handler:^(NSDictionary *a) {
        NSString *bid = a[@"bundle"];
        if (bid) [(SpringBoard *)[UIApplication sharedApplication] launchApplicationWithIdentifier:bid suspended:NO];
    }];
    [c registerAction:@"recentApp" handler:^(NSDictionary *a) {  // предыдущее приложение
        id m = NSClassFromString(@"SBAppSwitcherModel");
        if (!m) return;
        id model = [m performSelector:@selector(sharedInstance)];
        NSArray *ids = nil;
        for (NSString *n in @[@"identifiers", @"_recentsFromPrefs"])
            if ([model respondsToSelector:NSSelectorFromString(n)]) { ids = [model performSelector:NSSelectorFromString(n)]; break; }
        if (ids.count > 1) {
            id second = ids[1];
            NSString *bid = [second isKindOfClass:[NSString class]] ? second : [second valueForKey:@"displayIdentifier"];
            if (bid) [(SpringBoard *)[UIApplication sharedApplication] launchApplicationWithIdentifier:bid suspended:NO];
        }
    }];
}

#pragma mark - Внешние модули
static void S15LoadModules(void) {
    NSString *dir = @"/Library/Style15/Modules";
    for (NSString *f in [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dir error:nil]) {
        if (![f hasSuffix:@".bundle"]) continue;
        NSBundle *b = [NSBundle bundleWithPath:[dir stringByAppendingPathComponent:f]];
        if (![b load]) { NSLog(@"[style15] модуль %@ не загрузился", f); continue; }
        id inst = [[b principalClass] new];
        if ([inst respondsToSelector:@selector(moduleDidLoad)]) [inst moduleDidLoad];
        NSLog(@"[style15] модуль загружен: %@", f);
    }
}

static void S15PrefsChanged(CFNotificationCenterRef c, void *o, CFStringRef n, const void *x, CFDictionaryRef u) {
    CFPreferencesAppSynchronize(S15_DOMAIN);
    [[S15Core shared] postEvent:@"prefs.reload" info:nil];
}

%ctor {
    @autoreleasepool {
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, S15PrefsChanged,
            CFSTR("ru.style15.launcher/reload"), NULL, CFNotificationSuspensionBehaviorCoalesce);
        if (S15IsSpringBoard()) {
            S15RegisterBuiltins();
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 4 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{ S15LoadModules(); });
        }
    }
}
