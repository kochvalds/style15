#import "Style15API.h"

// Пример: своё действие "hello" + реакция на включение Пункта управления.
// Действие можно повесить на жест: в Gestures.plist  <key>topRightDown</key><string>hello</string>
@interface HelloModule : NSObject <S15Module>
@end

@implementation HelloModule
+ (NSString *)moduleName { return @"Hello"; }

- (void)moduleDidLoad {
    S15Core *core = [S15Core shared];

    [core registerAction:@"hello" handler:^(NSDictionary *args) {
        S15IslandActivity *a = [S15IslandActivity new];
        a.identifier = @"hello";
        a.leading = @"\U0001F44B";
        a.title = @"Привет из модуля!";
        a.subtitle = @"Это пользовательское действие";
        a.accent = [UIColor orangeColor];
        a.duration = 3;
        a.buttons = @[@{@"title": @"Скриншот", @"action": @"screenshot"},
                      @{@"title": @"Фонарик",  @"action": @"torch"}];
        [[S15Island shared] present:a];
    }];

    [core observeEvent:@"cc.shown" handler:^(NSDictionary *info) {
        NSLog(@"[HelloModule] открыт Пункт управления");
    }];
}
@end
